/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                   (c) Copyright 2018, Team No.3, Department of CSIE, Chang-Gung University
*                                           All Rights Reserved
*
*                                               Final Project
*********************************************************************************************************
*/

#include "includes.h"

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/

#define  TASK_STK_SIZE                 512       /* Size of each task's stacks (# of WORDs)            */
#define  N_TASKS_MAX                   8         /* Number of identical tasks                          */

#define  TASK_START_ID                 0         /* Application tasks IDs                              */
#define  TASK_CLK_ID                   1

#define  TASK_START_PRIO               10        /* Application tasks priorities                       */
#define  TASK_CLK_PRIO                 11

#define  PERIOD_TASK_START_ID		   20        /* Periodic Application tasks priority                */
#define  PERIOD_TASK_START_PRIO		   20        /* Periodic Application ID                            */

/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/

typedef struct{
	INT32U RemainTime;
	INT32U ExecutionTime;
	INT32U Period;
	INT32U Deadline;
}TASK_EXTRA_DATA;

OS_STK        TaskStk[N_TASKS_MAX][TASK_STK_SIZE];        /* Tasks stacks                              */
OS_STK        TaskStartStk[TASK_STK_SIZE];
OS_STK        TaskClkStk[TASK_STK_SIZE];

TASK_EXTRA_DATA  TaskEtrData[N_TASKS_MAX];				  /* Tasks Extra Data                          */

INT8U	      TaskNum[N_TASKS_MAX];                       /* Input file Information                    */
INT8U	      TaskExeTime[N_TASKS_MAX];
INT8U	      TaskPeriod[N_TASKS_MAX];

INT8U 	      N_TASKS;
INT8U         a = 6;
INT8U         b = 17;
INT8U         PreviousTaskNum;
INT8U         PreviousNum;
INT32U		  StartTime;

/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/

        void  PeriodTask (void *pdata);               /* Function prototypes of tasks                  */
        void  TaskStart(void *data);                  /* Function prototypes of Startup task           */
		void  TaskClk (void *data);                   /* Function prototypes of Clock task             */
static  void  Readfile(void);
static  void  TaskStartCreateTasks(void);
static  void  TaskStartDispInit(void);
static  void  TaskStartDisp(void);

/*$PAGE*/
/*
*********************************************************************************************************
*                                                MAIN
*********************************************************************************************************
*/

void  main (void)
{
    PC_DispClrScr(DISP_FGND_WHITE + DISP_BGND_BLACK);      /* Clear the screen                         */

    OSInit();                                              /* Initialize uC/OS-II                      */

    PC_DOSSaveReturn();                                    /* Save environment to return to DOS        */
    PC_VectSet(uCOS, OSCtxSw);                             /* Install uC/OS-II's context switch vector */

    Readfile();
	
	OSTaskCreateExt(TaskStart,
				    (void *)0,
				    &TaskStartStk[TASK_STK_SIZE - 1],
				    TASK_START_PRIO,
				    TASK_START_ID,
				    &TaskStartStk[0],
				    TASK_STK_SIZE,
				    (void *)0,
				    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
    OSStart();                                             /* Start multitasking                       */
}

/*
*********************************************************************************************************
*                                               Read File
*********************************************************************************************************
*/

void Readfile()
{
	FILE *finput;
	INT8U i, j, temp1, temp2, temp3;
	
	finput = fopen("Input1.txt","r");
	
	fscanf(finput, "%d", &N_TASKS);
	for( i=0; i<N_TASKS; i++){
		/* Information of tasks */
		TaskNum[i] = i+1;
		fscanf(finput, "%d", &TaskExeTime[i]);
		fscanf(finput, "%d", &TaskPeriod[i]);
	}
	
	fclose(finput);
	
	//Bubble Sort
	for( j=N_TASKS-1; j>0; j--){
		for( i=0; i<j; i++){
			if( TaskPeriod[i]>TaskPeriod[i+1] ){
				temp1 = TaskExeTime[i+1];
				temp2 = TaskPeriod[i+1];
				temp3 = TaskNum[i+1];
				TaskExeTime[i+1] = TaskExeTime[i];
				TaskPeriod[i+1] = TaskPeriod[i];
				TaskNum[i+1] = TaskNum[i];
				TaskExeTime[i] = temp1;
				TaskPeriod[i] = temp2;
				TaskNum[i] = temp3;
			}
		}
	}
	
	for( i=0; i<N_TASKS; i++){
		/* Extra Data Initialization */
		TaskEtrData[i].RemainTime = TaskExeTime[i] * OS_TICKS_PER_SEC;
		TaskEtrData[i].ExecutionTime = TaskExeTime[i] * OS_TICKS_PER_SEC;
		TaskEtrData[i].Period = TaskPeriod[i] * OS_TICKS_PER_SEC;
		TaskEtrData[i].Deadline = TaskPeriod[i] * OS_TICKS_PER_SEC;
	}
}

/*
*********************************************************************************************************
*                                              STARTUP TASK
*********************************************************************************************************
*/
void  TaskStart (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif
    INT8U     key;


    pdata = pdata;                                         /* Prevent compiler warning                 */

    TaskStartDispInit();                                   /* Initialize the display                   */

    OS_ENTER_CRITICAL();
    PC_VectSet(0x08, OSTickISR);                           /* Install uC/OS-II's clock tick ISR        */
    PC_SetTickRate(OS_TICKS_PER_SEC);                      /* Reprogram tick rate                      */
    OS_EXIT_CRITICAL();

    OSStatInit();                                          /* Initialize uC/OS-II's statistics         */

    TaskStartCreateTasks();                                /* Create all the application tasks         */

    for (;;) {
        TaskStartDisp();                                  /* Update the display                       */

        if (PC_GetKey(&key) == TRUE) {                     /* See if key has been pressed              */
            if (key == 0x1B) {                             /* Yes, see if it's the ESCAPE key          */
                PC_DOSReturn();                            /* Return to DOS                            */
            }
        }

        OSCtxSwCtr = 0;                                    /* Clear context switch counter             */
        OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                          */
    }
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                        INITIALIZE THE DISPLAY
*********************************************************************************************************
*/

static  void  TaskStartDispInit (void)
{
/*                                1111111111222222222233333333334444444444555555555566666666667777777777 */
/*                      01234567890123456789012345678901234567890123456789012345678901234567890123456789 */
    PC_DispStr( 0,  0, "                         uC/OS-II, The Real-Time Kernel                         ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  1, "                              OSP Fianl Project(RM)                             ", DISP_FGND_WHITE + DISP_BGND_BLUE);
    PC_DispStr( 0,  2, "                                     Team 8                                     ", DISP_FGND_WHITE + DISP_BGND_BLUE);
    PC_DispStr( 0,  3, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  4, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  5, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  6, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  7, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  8, "  Task   Execution Time  Period   Start Time   End Time   Deadline   Run Times  ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0,  9, " ------ --------------- -------- ------------ ---------- ---------- ----------- ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 10, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 11, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 12, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 13, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 14, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 15, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 16, " Task:                                         Time Counter:                    ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 17, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 18, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 19, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 20, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 21, "                                                                                ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 22, "#Tasks          :        ;CPU Usage:      %                                     ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 23, "#Task switch/sec:                                                               ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    PC_DispStr( 0, 24, "                            <-PRESS 'ESC' TO QUIT->                             ", DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY + DISP_BLINK);
/*                                1111111111222222222233333333334444444444555555555566666666667777777777 */
/*                      01234567890123456789012345678901234567890123456789012345678901234567890123456789 */
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                           UPDATE THE DISPLAY
*********************************************************************************************************
*/

static  void  TaskStartDisp (void)
{
    char   s[80];
    INT8U i, j;
	
    for( i=0,j=10; i<N_TASKS; i++,j++){
        sprintf(s, "Task%d", TaskNum[i]);
        PC_DispStr( 1, j, s, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
        sprintf(s, "%d", TaskExeTime[i]);
        PC_DispStr( 14, j, s, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
        sprintf(s, "%d", TaskPeriod[i]);
        PC_DispStr( 27, j, s, DISP_FGND_BLACK + DISP_BGND_LIGHT_GRAY);
    }
	
    sprintf(s, "%5d", OSTaskCtr);                                  /* Display #tasks running               */
    PC_DispStr(18, 22, s, DISP_FGND_PURPLE + DISP_BGND_LIGHT_GRAY);

#if OS_TASK_STAT_EN > 0
    sprintf(s, "%3d", OSCPUUsage);                                 /* Display CPU usage in %               */
    PC_DispStr(37, 22, s, DISP_FGND_PURPLE + DISP_BGND_LIGHT_GRAY);
#endif

    sprintf(s, "%5d", OSCtxSwCtr);                                 /* Display #context switches per second */
    PC_DispStr(18, 23, s, DISP_FGND_PURPLE + DISP_BGND_LIGHT_GRAY);

    //sprintf(s, "V%1d.%02d", OSVersion() / 100, OSVersion() % 100); /* Display uC/OS-II's version number    */
    //PC_DispStr(75, 24, s, DISP_FGND_DARK_GRAY + DISP_BGND_LIGHT_GRAY);

    //switch (_8087) {                                               /* Display whether FPU present          */
    /*    case 0:
             PC_DispStr(71, 22, " NO  FPU ", DISP_FGND_DARK_GRAY + DISP_BGND_LIGHT_GRAY);
             break;

        case 1:
             PC_DispStr(71, 22, " 8087 FPU", DISP_FGND_DARK_GRAY + DISP_BGND_LIGHT_GRAY);
             break;

        case 2:
             PC_DispStr(71, 22, "80287 FPU", DISP_FGND_DARK_GRAY + DISP_BGND_LIGHT_GRAY);
             break;

        case 3:
             PC_DispStr(71, 22, "80387 FPU", DISP_FGND_DARK_GRAY + DISP_BGND_LIGHT_GRAY);
             break;
    }*/
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                             CREATE TASKS
*********************************************************************************************************
*/

static  void  TaskStartCreateTasks (void)
{
    INT8U  i;
	StartTime = OSTimeGet();
	
	OSTaskCreateExt(TaskClk,
                    (void *)0,
                    &TaskClkStk[TASK_STK_SIZE - 1],
                    TASK_CLK_PRIO,
                    TASK_CLK_ID,
                    &TaskClkStk[0],
                    TASK_STK_SIZE,
                    (void *)0,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
	
    for (i = 0; i < N_TASKS; i++) {                        /* Create N_TASKS identical tasks           */
	
		OSTaskCreateExt(PeriodTask,
				        (void *)0,
				        &TaskStk[i][TASK_STK_SIZE - 1],
				        (PERIOD_TASK_START_PRIO + i),
				        (PERIOD_TASK_START_ID + i),
				        &TaskStk[i][0],
				        TASK_STK_SIZE,
				        &TaskEtrData[i],
				        OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
    }
	
}

/*
*********************************************************************************************************
*                                                  TASKS
*********************************************************************************************************
*/

void  PeriodTask (void *pdata)
{
    INT8U x;
	INT8U FirstEntry;
	TASK_EXTRA_DATA *Myptr;
	char s[34];
	INT32U TaskTime;
	
	pdata = pdata;
	Myptr = OSTCBCur->OSTCBExtPtr;
	x = 0;

	//Initialization
	Myptr->Deadline = StartTime + Myptr->Period;
	Myptr->RemainTime = Myptr->ExecutionTime;
	
    for (;;) {
		/*** Run times ***/
        x++;
		sprintf(s, "%4d", x);
		PC_DispStr(71, 10+OSPrioCur-PERIOD_TASK_START_PRIO, s, DISP_FGND_RED+DISP_BGND_LIGHT_GRAY);
		
		/*** Start Time ***/
		sprintf(s, "%10d", (OSTimeGet()-StartTime)/OS_TICKS_PER_SEC);
		PC_DispStr(34, 10+OSPrioCur-PERIOD_TASK_START_PRIO, s, DISP_FGND_YELLOW+DISP_BGND_LIGHT_GRAY);
		
		/*** Deadline ***/
		sprintf(s, "%10d", Myptr->Deadline/OS_TICKS_PER_SEC);
		PC_DispStr(57, 10+OSPrioCur-PERIOD_TASK_START_PRIO, s, DISP_FGND_BLUE+DISP_BGND_LIGHT_GRAY);
		
		FirstEntry = 1;
		PreviousTaskNum = TaskNum[OSPrioCur-PERIOD_TASK_START_PRIO];
		
		while(1){
			if( PreviousNum!=TaskNum[OSPrioCur-PERIOD_TASK_START_PRIO] ){
				// Context-switching occurs!
				//Print context-switching information
				sprintf(s, "Context switch! task%d to task%d.", PreviousNum, TaskNum[OSPrioCur-PERIOD_TASK_START_PRIO]);
		        PC_DispStr(8, 16, s, DISP_FGND_BLACK+DISP_BGND_LIGHT_GRAY);
			}
		    PreviousNum = TaskNum[OSPrioCur-PERIOD_TASK_START_PRIO];
			
			//Print Task Sequence
			if( FirstEntry==1 ){
				sprintf(s, "%d", TaskNum[OSPrioCur-PERIOD_TASK_START_PRIO]);
		        PC_DispStr(a, b, s, DISP_FGND_LIGHT_BLUE+DISP_BGND_LIGHT_GRAY);
				a++;
			
				FirstEntry = 0;
			}
			else if( PreviousTaskNum!=TaskNum[OSPrioCur-PERIOD_TASK_START_PRIO] ){
				// Context-switching occurs!
				
				//Print task sequence
				sprintf(s, "%d", TaskNum[OSPrioCur-PERIOD_TASK_START_PRIO]);
		        PC_DispStr(a, b, s, DISP_FGND_LIGHT_BLUE+DISP_BGND_LIGHT_GRAY);
				a++;
				
				PreviousTaskNum = TaskNum[OSPrioCur-PERIOD_TASK_START_PRIO];
			}
				
			if( Myptr->RemainTime <=0){
				break;
			}
			else{
			INT32U temp;
			temp = OSTimeGet();
				while(1){if((temp-OSTimeGet())>=OS_TICKS_PER_SEC)break;}
			Myptr->RemainTime--;
			}



			//Setting of task sequence printing
			if( a>44 ){
				a = 4;
				b++;
			}
			if( b>20 ){
				PC_DispClrRow(17, DISP_BGND_LIGHT_GRAY);
				PC_DispClrRow(18, DISP_BGND_LIGHT_GRAY);
				PC_DispClrRow(19, DISP_BGND_LIGHT_GRAY);
				PC_DispClrRow(20, DISP_BGND_LIGHT_GRAY);
				b = 17;
				a = 6;
			}
		}	
		Myptr->Deadline = Myptr->Deadline + Myptr->Period;
		Myptr->RemainTime = Myptr->ExecutionTime;
		
		sprintf(s, "%10d", (OSTimeGet()-StartTime)/OS_TICKS_PER_SEC);
		PC_DispStr(46, 10+OSPrioCur-PERIOD_TASK_START_PRIO, s, DISP_FGND_GREEN+DISP_BGND_LIGHT_GRAY);
		
		if( (Myptr->Deadline - Myptr->Period) > OSTimeGet() ){
			OSTimeDly( Myptr->Deadline - Myptr->Period - OSTimeGet() );
		
		}
    }
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                               CLOCK TASK
*********************************************************************************************************
*/

/* To get the time from PC server and display on the screen */
void  TaskClk (void *data)
{
    char s[40];

    data = data;
    for (;;) {
        PC_GetDateTime(s);
        PC_DispStr(60, 23, s, DISP_FGND_DARK_GRAY + DISP_BGND_LIGHT_GRAY);
		sprintf(s, "%10d", (OSTimeGet()-StartTime)/OS_TICKS_PER_SEC);
        PC_DispStr(61, 16, s, DISP_FGND_WHITE + DISP_BGND_LIGHT_GRAY);
        OSTimeDly(OS_TICKS_PER_SEC);
    }
}
